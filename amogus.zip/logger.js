export function log(message) {
  console.log(message)
}
