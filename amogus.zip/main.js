import { log } from './logger'

log('Import works!')
